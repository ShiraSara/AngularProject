
import { HttpClient, HttpEventType } from '@angular/common/http';
import { Output } from '@angular/core';
import { Component,OnInit,AfterViewInit , ViewChild, ElementRef  } from '@angular/core'; 
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ModalDirective, ModalModule } from 'angular-bootstrap-md';
import { EventEmitter } from 'events';
import { storage } from '../Model/storage';
import { StorageService } from '../service/storage.service';





@Component({
  selector: 'app-mangar',
  templateUrl: './mangar.component.html',
  styleUrls: ['./mangar.component.css']
})
export class MangarComponent implements OnInit {

  public myForm:FormGroup;
  flag:boolean=false;
  userName:string="";
  url?: string="";
  flag1:boolean=true;
  s:storage;
  password:string="";
  selectFile:File=null;
  isShow:boolean=false
  validatingForm: FormGroup;
  public progress: number;
  public message: string="";
  @Output() public onUploadFinished = new EventEmitter();
  c:number=3;
  x:number;
  y:number;
  showModal:boolean=false;
  constructor(private http:HttpClient,private storageService:StorageService,private r:Router) { }

  
  ngOnInit(){
  this.myForm=new FormGroup({
    userName:new FormControl('',[Validators.required]),
    password:new FormControl('',[Validators.required])
  });
  this.validatingForm = new FormGroup({
    nameStorage: new FormControl('', Validators.required)
  });
  }

//החזרת איקס ו וואי של מפה
  getPercentage(elem:any)
  {
  this.x = elem.offsetX;
  this.y= elem.offsetY;
  document.getElementById("x").innerText+=this.x;
  document.getElementById("y").innerText+=this.y;
  }
  
  //הצגת התמונה ברגע שהיא נבחרת
  onSelectFile(event:any) { // called each time file input changes
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
this.selectFile=event.target.files[0];
      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        this.url = event.target?.result?.toString();
      }
     this.selectFile=event.target.files[0];
    }

 
}
//אימות פרטי מנהל
onSubmit(form:FormGroup)
{
this.userName=form.value.userName;
this.password=form.value.password;
if(this.password=="admin" && this.userName=="admin")
{
alert(" אנא העלה מפה מסוג תמונה");
this.flag=true;
}
else
alert("שם משתמש או סיסמא אינם נכונים");
this.userName="";
}


//הוספת מחסן לשרת
AddStorage()
{
  this.s=new storage(undefined,this.validatingForm.value.nameStorage,this.x,this.y);
  console.log(this.s);
  this.storageService.AddStorage(this.s).subscribe(data=>alert("המחסן הוסף בהצלחה לרשימת המחסנים"),err=>alert("בעייה בחיבור לשרת, המחסן לא הוסף"))
}

//שמירת התמונה בשרת
public uploadFile = () => {
  const formData = new FormData();
  formData.append('file', this.selectFile, this.selectFile.name);
  this.http.post('https://localhost:44353/api/Uploade', formData, {reportProgress: true, observe: 'events'})
    .subscribe(event => {
      if (event.type === HttpEventType.UploadProgress)
        this.progress = Math.round(100 * event.loaded / event.total);
      else if (event.type === HttpEventType.Response) {
        this.message = 'Upload success.';
        this.onUploadFinished.emit(event.body.toString());
      }
    });
}
//העלת קובץ הזמנות לשרת
public uploadFile1 = () => {
  const formData = new FormData();
  formData.append('file', this.selectFile, this.selectFile.name);
  this.http.post('https://localhost:44353/api/Uploade/UploadExcel', formData, {reportProgress: true, observe: 'events'})
    .subscribe(event => {
      if (event.type === HttpEventType.UploadProgress)
        this.progress = Math.round(100 * event.loaded / event.total);
      else if (event.type === HttpEventType.Response) {
        this.message = 'Upload success.';
        this.onUploadFinished.emit(event.body.toString());
      }
    });
}
a()
{
this.r.navigate(['/collector-table']);
}
}
