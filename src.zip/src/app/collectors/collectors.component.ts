import { ViewChild } from '@angular/core';
import { HostListener } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { ElementRef } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MdbTableDirective, MdbTablePaginationComponent } from 'angular-bootstrap-md';
import { collector } from '../Model/collector';
import { orders } from '../Model/orders';
import { CollectorsService } from '../service/collectors.service';
import { OrdersService } from '../service/orders.service';



@Component({
  selector: 'app-collectors',
  templateUrl: './collectors.component.html',
  styleUrls: ['./collectors.component.css']
})
export class CollectorsComponent implements OnInit {

  flag:boolean=false;
  newCollector:collector=new collector();
  validatingForm: FormGroup;
  selectFile:File=null;
  flag2:boolean=false;
  url?:string;
  ordersList:Array<orders>=new Array<orders>();
  @ViewChild(MdbTableDirective, { static: true }) mdbTable: MdbTableDirective;
  @ViewChild(MdbTablePaginationComponent, { static: true }) mdbTablePagination: MdbTablePaginationComponent;
  @ViewChild('row', { static: true }) row: ElementRef;

  elements:orders[]=[];
  headElements = ['קוד הזמנה','תאריך הזמנה','תאריך ביצוע','קובץ','מצב','קוד מלקט'];

  searchText: string = '';
  previous: string;
  constructor(private collectorService:CollectorsService,private r:Router,private ordersService:OrdersService) { }
  @HostListener('input') oninput() {
    this.mdbTablePagination.searchText = this.searchText;
  }
  ngOnInit(){
    this.validatingForm = new FormGroup({
      modalFormElegantUserName: new FormControl('', Validators.required),
      modalFormElegantPassword: new FormControl('', Validators.required)
    });

    this.mdbTable.setDataSource(this.elements);
    this.elements = this.mdbTable.getDataSource();
    this.previous = this.mdbTable.getDataSource();
  
  }
  login()
  {
  this.collectorService.Login(this.validatingForm.value.modalFormElegantUserName,this.validatingForm.value.modalFormElegantPassword).subscribe(data=>{this.newCollector=data,this.checkUser()},err=>console.log(err))
  }
  checkUser()
  {
    if(this.newCollector!=null)
    {
      alert("ברוך הבא"+" "+this.newCollector.nameCollector+"הנך מועבר לדף הליקוט");
      this.flag=true;
    }
    else {
      alert("שם או סיסמא אינם נכונים, אנא נסה שנית");
      this.validatingForm.value.modalFormElegantPassword="";
      this.validatingForm.value.modalFormElegantUserName="";
    }
    


  }

  onSelectFile(event:any) { // called each time file input changes
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
this.selectFile=event.target.files[0];
      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        this.url = event.target?.result?.toString();
      }
     this.selectFile=event.target.files[0];
    }

 
}
begain()
{
  this.r.navigate(['/track'])
}
//הצגת הזמנות
GetOrders(code:number)
{
  this.flag2=true;
  //הצגת כל ההזמנות
  if(code==0)
  {
this.ordersService.GetOrders().subscribe(data=>this.elements=data,err=>console.log(err))
console.log(this.elements)
  }
  //הצגת הזמנות שבוצעו
  else if(code==1)
  {
this.ordersService.GetOrdersPlaced().subscribe(data=>this.elements=data,err=>console.log(err))
  }
  //הצגת הזמנות לביצוע
  else{
this.ordersService.GetOrdersNotPlaced().subscribe(data=>this.elements=data,err=>console.log(err))
  }
}


emitDataSourceChange() {
  this.mdbTable.dataSourceChange().subscribe((data: any) => {
    console.log(data);
  });
}

searchItems() {
  const prev = this.mdbTable.getDataSource();

  if (!this.searchText) {
    this.mdbTable.setDataSource(this.previous);
    this.elements = this.mdbTable.getDataSource();
  }

  if (this.searchText) {
    this.elements = this.mdbTable.searchLocalDataBy(this.searchText);
    this.mdbTable.setDataSource(prev);
  }

  this.mdbTablePagination.calculateFirstItemIndex();
  this.mdbTablePagination.calculateLastItemIndex();

  this.mdbTable.searchDataObservable(this.searchText).subscribe(() => {
    this.mdbTablePagination.calculateFirstItemIndex();
    this.mdbTablePagination.calculateLastItemIndex();
  });
}

}
