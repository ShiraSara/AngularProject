import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sigh-out',
  templateUrl: './sigh-out.component.html',
  styleUrls: ['./sigh-out.component.css']
})
export class SighOutComponent implements OnInit {

  
  constructor() { }

  ngOnInit(): void {
  }

}
