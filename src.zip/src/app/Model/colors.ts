export class colors{
    constructor(public codeColor?:number,public nameColor?:string){}
}