export class productModels{
    constructor(public codeModel?:number,public codeProduct?:number,public size?:number,public codeColor?:number,public countInStock?:number,public price?:number,public column?:number,public position?:number,public shelf?:number){}
}