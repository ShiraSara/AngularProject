export class collector{
    constructor(public codeCollector?:number,public nameCollector?:string,public username?:string,public passowrd?:string,public email?:string){};
}