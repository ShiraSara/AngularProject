export class productsOnOrder{
    constructor(public codeProductsOnOrder?:number,public codeOrder?:number,public codeModel?:number,public count?:number,public status?:number){}
}