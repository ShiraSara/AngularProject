export class storage{
    constructor(public codeStorage?:number,public nameStorage?:string,public x?:number,public y?:number){}
}