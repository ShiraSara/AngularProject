export class products
{
    constructor(public codeProduct?:number,public nameProduct?:string,public codeGroup?:number,public codeStorage?:number){}
} 