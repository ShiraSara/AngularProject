export class productGroups{
constructor(public CcdeGroups?:number,public naneGroups?:string){}
}