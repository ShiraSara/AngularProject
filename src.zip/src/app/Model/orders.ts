export class orders{
    constructor(public codeOrder?:number,public dateOrder?:Date,public executionDate?:Date,public productFile?:number,public status?:number,public codeCollector?:number){}
}