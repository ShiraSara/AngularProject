import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { collector } from '../Model/collector';

@Injectable({
  providedIn: 'root'
})
export class CollectorsService {
  collector1:collector
  baseUrl="https://localhost:44353/";
  collectorUrl="api/Collector/"
  constructor(private http:HttpClient) { }

   //החזרת כל המלקטים
   GetAllCollector():Observable<collector[]>{
    return this.http.get<collector[]>(this.baseUrl+this.collectorUrl+"GetCollectors");
   }
   //מחיקת מלקט
   DeleteCollector(codeCollector:number):Observable<collector[]>
   {
  return this.http.delete<collector[]>(this.baseUrl+this.collectorUrl+"DeleteCollector/"+codeCollector);
   }
   //הוספת מלקט
   AddCollector(c:collector):Observable<collector[]>
   {
     debugger;
    return this.http.post<collector[]>(this.baseUrl+this.collectorUrl+"AddCollector",c);
   }
   //עדכון מלקט
   UpdateCollector(codeCollector:number,c:collector):Observable<collector[]>
   {
     return this.http.put<collector[]>(this.baseUrl+this.collectorUrl+"UpdateCollector/"+codeCollector,c);
   }
   //אימות מלקט
   Login(userName:string,password:string):Observable<collector>{
     return this.http.get<collector>(this.baseUrl+this.collectorUrl+"Login/"+userName+"/"+password);
   }
   //אינדקס הכי גבוה
   Index():Observable<number>{
     return this.http.get<number>(this.baseUrl+this.collectorUrl+"Index");
   }

}
