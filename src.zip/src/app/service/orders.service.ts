import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { orders } from '../Model/orders';

@Injectable({
  providedIn: 'root'
})
export class OrdersService {

  baseUrl="https://localhost:44353/";
  OrderUrl="api/Order/";
  constructor(private http:HttpClient) { }
  
  //כל ההזמנות
  GetOrders():Observable<orders[]>{
    return this.http.get<orders[]>(this.baseUrl+this.OrderUrl+"GetOrders");
  }
  //הזמנות שבוצעו
  GetOrdersPlaced():Observable<orders[]>{
    return this.http.get<orders[]>(this.baseUrl+this.OrderUrl+"GetOrdersPlaced");
  }
  //הזמנות שלא בוצעו
  GetOrdersNotPlaced():Observable<orders[]>{
    return this.http.get<orders[]>(this.baseUrl+this.OrderUrl+"GetOrdersNotPlaced");
  }
}
