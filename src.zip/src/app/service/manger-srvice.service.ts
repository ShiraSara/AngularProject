import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { observable, Observable } from 'rxjs';
import { collector } from '../Model/collector';

@Injectable({
  providedIn: 'root'
})
export class MangerSrviceService {

 
  constructor(private http:HttpClient) { }



}
