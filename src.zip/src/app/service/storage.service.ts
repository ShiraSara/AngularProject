import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { storage } from '../Model/storage';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
baseUrl="https://localhost:44353/"
storageUrl="api/Storage/"
  constructor(private http:HttpClient) { }

  //הוספת מחסן
  AddStorage(s:storage):Observable<storage[]>
  {
    return this.http.post<storage[]>(this.baseUrl+this.storageUrl+"AddStorage",s);
  }
}
