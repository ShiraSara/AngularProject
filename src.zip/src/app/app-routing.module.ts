import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CollectorTableComponent } from './collector-table/collector-table.component';
import { CollectorsComponent } from './collectors/collectors.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { MangarComponent } from './mangar/mangar.component';
import { OdotComponent } from './odot/odot.component';
import { RegistrationComponent } from './registration/registration.component';
import { SighOutComponent } from './sigh-out/sigh-out.component';
import { TrackComponent } from './track/track.component';



const routes: Routes = 
[
{path:'login',component:LoginComponent},
{path:'header',component:HeaderComponent},
{path:'registration',component:RegistrationComponent},
{path:'odot',component:OdotComponent},
{path:'sigh-out',component:SighOutComponent},
{path:'mangar',component:MangarComponent},
{path:'footer',component:FooterComponent},
{path:'collectors',component:CollectorsComponent},
{path:'track',component:TrackComponent},
{path:'collector-table',component:CollectorTableComponent}
];


@NgModule({
  declarations: [],
  imports: [RouterModule.forRoot(routes)],
  
})
export class AppRoutingModule { }
