import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-odot',
  templateUrl: './odot.component.html',
  styleUrls: ['./odot.component.css']
})
export class OdotComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
