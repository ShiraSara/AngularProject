
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import{ReactiveFormsModule} from '@angular/forms'
import{HeaderComponent} from 'src/app/header/header.component';
import { LoginComponent } from './login/login.component';
import {RouterModule,Routes} from '@angular/router'
import { FooterComponent } from './footer/footer.component';
import { RegistrationComponent } from './registration/registration.component';
import { SighOutComponent } from './sigh-out/sigh-out.component';
import { OdotComponent } from './odot/odot.component';
import { MangarComponent } from './mangar/mangar.component';
import {TrackComponent} from './track/track.component'
import {HttpClientModule} from '@angular/common/http';
import {CollectorsComponent} from './collectors/collectors.component';
import { CollectorTableComponent } from './collector-table/collector-table.component'


@NgModule({
  declarations: [
    AppComponent, HeaderComponent,
    LoginComponent,FooterComponent,RegistrationComponent,SighOutComponent,OdotComponent,MangarComponent,
    CollectorsComponent,TrackComponent,
    CollectorTableComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MDBBootstrapModule.forRoot(),
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
